const express = require('express');
const apiRoutes = require('./api/index');
const app = express();

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use('/api', apiRoutes);
/*
app.use(
  express.json({
    limit: '50mb',
  }),
);
*/

/*
app.use((err, req, res, next) => {
  res.status(500).json({ statusCode: res.statusCode, errMessage: err.message });
});

app.get('/error2', (req, res, next) => {
  next(new Error('에러 발생!'));
});
*/
app.listen(5000, () => {
  console.log(
    'Hello Zum-Board! My Nickname is yoonOcean -> http://localhost:5000',
  );
});
