const fs = require('fs');

// 01.19 fs 를 비동기로 R/W 할지 동기로 진행할지 고민

const postData = exports.getData();

exports.getData = () => {
  /* JSON 파일을 string 형태로 읽어서 JSON 형태로 변환하여 읽음 */
  const dataBuffer = fs.readFileSync('data.json', 'utf-8');
  const convJSON = JSON.parse(dataBuffer);
  return convJSON;
};
exports.setData = (data) => {
  /* JSON 파일을 string 형태로 저장함 */
  const dataToJSON = JSON.stringify(data);
  fs.writeFileSync('data.json', dataToJSON, 'utf-8');
};
exports.lastPostId = () => {
  /* JSON 파일내에 마지막 포스트 postId 를 가져옴 */
  // 가져오기전 캐싱된 데이터를 가져오지 않도록 새로 불러옴
  this.getData();
  return postData[postData.length - 1].postId;
};
exports.refresh = (data) => {
  /* 캐싱된 데이터를 set, get 하여 실제 저장된 데이터를 불러옴 */
  this.setData(data);
  this.getData();
};
