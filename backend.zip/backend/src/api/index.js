const express = require('express');
const router = express.Router();
const postCtrl = require('./post/postCtrl');

router.post('/', postCtrl.Create);
router.get('/', postCtrl.readList);
router.get('/:postId', postCtrl.read);
router.patch('/:postId', postCtrl.update);
router.delete('/:postId', postCtrl.delete);

module.exports = router;
